async function fetchStudentData(): Promise<{ name: string; grades: number[] }> {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const success = true; 
            
            if (success) {
                const studentData = {
                    name: "Naomi",
                    grades: [85, 90, 78, 92]
                };
                resolve(studentData); 
            } else {
                reject(new Error("Failed to fetch student data.")); 
            }
        }, 2000); 
    });
}

async function main() {
    try {
        const student = await fetchStudentData(); 
        console.log(`Student Name: ${student.name}`); 
        console.log(`Grades: ${student.grades.join(", ")}`); 
    } catch (error) {
        console.error(error); 
    }
}
main();