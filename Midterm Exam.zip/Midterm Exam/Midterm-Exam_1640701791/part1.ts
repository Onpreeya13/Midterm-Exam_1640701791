class Student1 {
    name: string;    
    age: number;    
    grades: number[]; 

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
        this.grades = []; 
    }

    addGrade(grade: number): void {
        this.grades.push(grade); 
    }

    getAverageGrade(): number {
        if (this.grades.length === 0) {
            return 0; 
        }
        const total = this.grades.reduce((sum, grade) => sum + grade, 0); 
        return total / this.grades.length; 
    }

}

const student1 = new Student1("Onpreeya", 22); 
student1.addGrade(85);
student1.addGrade(90); 
console.log(student1.getAverageGrade());