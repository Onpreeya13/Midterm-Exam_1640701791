function parseJSONData(jsonData: string): { name: string; grades: number[] } | string {
    try {
        const studentData = JSON.parse(jsonData);

        if (typeof studentData.name !== "string" || !Array.isArray(studentData.grades)) {
            throw new Error("Invalid data format: name must be a string and grades must be an array.");
        }

        return studentData; 
    } catch (error) {
        return `Error parsing JSON data: ${error instanceof Error ? error.message : error}`;
    }
}

const jsonDataValid = '{"name": "Naomi", "grades": [85, 90, 78]}';
const jsonDataInvalid = '{"name": "John", "grades": "not an array"}';
const jsonDataMalformed = '{"name": "Alice", "grades": [90, 85'; 

console.log(parseJSONData(jsonDataValid)); 

console.log(parseJSONData(jsonDataInvalid)); 

console.log(parseJSONData(jsonDataMalformed)); 