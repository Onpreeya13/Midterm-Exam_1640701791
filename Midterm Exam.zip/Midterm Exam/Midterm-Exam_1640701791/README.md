# Midterm-Exam_1640701791
# part1
# สร้างคลาส Studentให้มี name, age, และ grades สร้างaddGrade ใช้เพิ่มเกรดไปในอาร์เรย์ grades สร้างgetAverageGrade ใช้คำนวณค่าเฉลี่ยเกรดในอาร์เรย์ grades
# part2
# สร้างคลาส Person มี name และ age คอนสตรัคเตอร์ใช้กำหนดค่าเริ่มต้น name และ age สร้างคลาส Studentอ้างอิ้ง name และ age จาก Personมี grades สร้างaddGrade เพิ่มเกรดไปยัง grades สร้างgetAverageGradeคำนวณและคืนค่าเกรดเฉลี่ย สร้าง คลาส Teacher:อ้างอิงคลาส Person ซึ่งหมายความว่า Teacher จะมีคุณสมบัติ name และ age มี subjectมีอาร์เรย์ students สร้างassignGrades เพื่อมอบเกรดให้กับนักเรียน โดยเรียกใช้เมธอด addGrade
# part3
# สร้างอินเทอร์เฟซ Admin มีnamedepartment ฟังก์ชัน getAdminInfo ฟังก์ชันนี้รับ admin ที่สอดคล้องกับอินเทอร์เฟซ Admin จะแสดงผลชื่อและแผนก
# part4
# คลาสทั่วไป Database เป็นคลาสเก็บวัตถุ โดยใช้ประเภท T มีอาร์เรย์ entries สร้างaddEntry(entry: T): void ใช้เพิ่มข้อมูลเข้ามาในฐานข้อมูลสร้างgetAllEntries(): T[] คืนค่าอาร์เรย์ของข้อมูลทั้งหมดที่เก็บ
# part5
# ฟังก์ชัน createBonusAdder(bonus: number): รับพารามิเตอร์ bonus เพื่อเพิ่มเป็นโบนัสให้กับเกรดคืนฟังก์ชันใหม่ที่รับพารามิเตอร grade เกรดที่ต้องการเพิ่มโบนัสในฟังก์ชันที่คืนมา จะทำการคืนค่า grade + bonus 
# part6
# ฟังก์ชัน fetchStudentData: ประกาศ async จะคืนค่าเป็น Promiseใช้ Promise เพื่อดึงข้อมูลจาก API โดยใช้ setTimeout ถ้าสำเร็จ (ตัวแปร success เป็น true), จะสร้างอ็อบเจกต์ studentData ที่มีชื่อและเกรด แล้วใช้ resolve เพื่อส่งคืนข้อมูลถ้าเกิดข้อผิดพลาด (ตัวแปร success เป็น false), จะใช้ reject เพื่อส่งคืนข้อผิดพลาด ฟังก์ชัน main ใช้ async เพื่อให้ await ได้ใช้ await fetchStudentData() เพื่อรอผลลัพธ์จาก fetchStudentDataใช้ try...catch เพื่อจัดการข้อผิดพลาดที่เกิดขึ้นเมื่อเรียกใช้ฟังก์ชัน
# part7
# คลาส Student มี name และ grades มีaddGrade เพิ่มเกรดและ getAverageGrade คำนวณเกรดเฉลี่ย สร้างอาร์เรย์ students เพิ่มเกรด ที่addGrade สร้าง filter ใช้เพื่อส่งกลับนักเรียนที่มีเกรดเฉลี่ยมากกว่า 75 โดยใช้ getAverageGrade แสดงรายชื่อนักเรียนที่ผ่านเกณฑ์ด้วย forEach() มีmapใช้สร้างอาร์เรย์ของชื่อของนักเรียน โดยคืนค่าชื่อของนักเรียน มีreduce ใช้คำนวณจำนวนเกรดรวมทั้งหมดที่ได้รับจากนักเรียน โดยนับจำนวนของเกรดในอาร์เรย์ grades 
# part8
# ฟังก์ชัน parseJSONData(jsonData: string): รับพารามิเตอร์ jsonData ซึ่งเป็นสตริง JSON ใช้ try แปลง JSON string ด้วย JSON.parse() แปลงสำเร็จ จะตรวจสอบว่า studentData มีรูปแบบที่ถูกต้องหรือไม่ โดยตรวจสอบว่าคุณสมบัติ name เป็นสตริงและ grades เป็นอาร์เรย์ หากรูปแบบไม่ถูกต้อง จะโยน (throw) ข้อผิดพลาดใหม่
# part9
# ในฟังก์ชันที่ถูกเรียกเมื่อฟอร์มถูกส่ง:ใช้ event.preventDefault() เพื่อป้องกันการรีเฟรชหน้าเว็บรับค่าจาก input ด้วย $('#studentName').val()เพิ่มชื่อของนักเรียนในรายการ #studentList ด้วย append()แสดงการแจ้งเตือนโดยใช้ alert()เคลียร์ค่าใน input field ด้วย $('#studentName').val('')