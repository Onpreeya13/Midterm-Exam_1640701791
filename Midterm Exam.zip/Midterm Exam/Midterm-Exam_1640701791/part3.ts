interface Admin {
    name: string;        
    department: string;  
}

function getAdminInfo(admin: Admin): void {
    console.log(`Admin Name: ${admin.name}`);       // แสดงชื่อผู้ดูแลระบบ
    console.log(`Department: ${admin.department}`); // แสดงแผนกของผู้ดูแลระบบ
}

const admin1: Admin = {
    name: "Onpreeya",
    department: "IT Support"
};

getAdminInfo(admin1);
