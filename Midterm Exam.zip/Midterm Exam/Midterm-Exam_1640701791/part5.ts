function createBonusAdder(bonus: number): (grade: number) => number {
    return function(grade: number): number {
        return grade + bonus; 
    };
}

const add10Bonus = createBonusAdder(10);
const add5Bonus = createBonusAdder(5);  

const grade1 = 85;
const grade2 = 90;

console.log(`Grade with 10 bonus: ${add10Bonus(grade1)}`); 
console.log(`Grade with 5 bonus: ${add5Bonus(grade2)}`);
