class Student7 {
    name: string;
    grades: number[];

    constructor(name: string) {
        this.name = name;
        this.grades = [];
    }

    addGrade(grade: number): void {
        this.grades.push(grade);
    }

    getAverageGrade(): number {
        if (this.grades.length === 0) return 0;
        const total = this.grades.reduce((sum, grade) => sum + grade, 0);
        return total / this.grades.length;
    }
}

const students: Student7[] = [
    new Student7("Naomi"),
    new Student7("John"),
    new Student7("Alice"),
    new Student7("Bob"),
];

students[0].addGrade(80);
students[0].addGrade(70);
students[0].addGrade(90);

students[1].addGrade(60);
students[1].addGrade(80);
students[1].addGrade(70);

students[2].addGrade(85);
students[2].addGrade(90);
students[2].addGrade(95);

students[3].addGrade(50);
students[3].addGrade(60);
students[3].addGrade(70);

const studentsAbove75 = students.filter(student => student.getAverageGrade() > 75);
console.log("Students with an average grade above 75:");
studentsAbove75.forEach(student => console.log(student.name));

const studentNames = students.map(student => student.name);
console.log("Student Names:", studentNames);

const totalGrades = students.reduce((total, student) => total + student.grades.length, 0);
console.log("Total number of grades given:", totalGrades);