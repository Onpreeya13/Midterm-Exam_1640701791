class Person {
    name: string; 
    age: number;  

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
    }
}

class Student2 {
    name: string;
    age: number;
    grades: number[];

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
        this.grades = [];
    }

    addGrade(grade: number): void {
        this.grades.push(grade);
    }

    getAverageGrade(): number {
        if (this.grades.length === 0) return 0;
        const total = this.grades.reduce((sum, grade) => sum + grade, 0);
        return total / this.grades.length;
    }
}

class Teacher extends Person {
    subject: string;         
    students: Student2[];     

    constructor(name: string, age: number, subject: string) {
        super(name, age); 
        this.subject = subject;
        this.students = []; 
    }

    assignGrades(student: Student2, grade: number): void {
        student.addGrade(grade); 
    }
}

const student2 = new Student2("Naomi", 20);
const teacher1 = new Teacher("Mr. Smith", 35, "Mathematics");


teacher1.assignGrades(student2, 90);
console.log(student2.getAverageGrade()); 
