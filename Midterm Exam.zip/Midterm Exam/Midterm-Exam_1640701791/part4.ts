class Student4 {
    name: string;
    age: number;
    grades: number[];

    constructor(name: string, age: number) {
        this.name = name;
        this.age = age;
        this.grades = [];
    }

    addGrade(grade: number): void {
        this.grades.push(grade);
    }

    getAverageGrade(): number {
        if (this.grades.length === 0) return 0;
        const total = this.grades.reduce((sum, grade) => sum + grade, 0);
        return total / this.grades.length;
    }
}

class Teacher4 {
    name: string;
    age: number;
    subject: string;

    constructor(name: string, age: number, subject: string) {
        this.name = name;
        this.age = age;
        this.subject = subject;
    }
}

class Database<T> {
    private entries: T[];

    constructor() {
        this.entries = []; 
    }

    addEntry(entry: T): void {
        this.entries.push(entry); 
    }

    getAllEntries(): T[] {
        return this.entries; 
    }
}

const studentDatabase = new Database<Student4>(); 
const teacherDatabase = new Database<Teacher>(); 

const student1p4 = new Student4("Naomi", 20);
const student2p4 = new Student4("John", 21);
studentDatabase.addEntry(student1p4); 
studentDatabase.addEntry(student2p4); 

const teacher1p4 = new Teacher4("Mr. Smith", 35, "Mathematics");
teacherDatabase.addEntry(teacher1); 

console.log(studentDatabase.getAllEntries()); 
console.log(teacherDatabase.getAllEntries()); 
